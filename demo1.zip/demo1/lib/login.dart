import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert'; // For JSON decoding
import 'home.dart'; // Import HomeScreen

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: LoginScreen(),
  ));
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  // Define your base URL and API endpoint
  final String _baseUrl = 'https://api.vanigargal.com';
  final String _loginEndpoint = '/merchantLogin';

  Future<void> _login() async {
    setState(() {
      _isLoading = true; // Show loading indicator
    });

    final String mobile = _mobileController.text;
    final String password = _passwordController.text;

    // Prepare the request body
    final Map<String, String> requestBody = {
      'mobile': mobile,
      'password': password,
    };

    try {
      // Make the POST request
      final response = await http.post(
        Uri.parse(_baseUrl + _loginEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(requestBody),
      );

      if (response.statusCode == 200) {
        // Parse the response
        final data = json.decode(response.body);

        if (data['status'] == 'success') {
          // Login successful, navigate to HomeScreen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
          );
        } else {
          // Show an error message if login fails
          _showErrorDialog('Login failed: ${data['message']}');
        }
      } else {
        _showErrorDialog('Failed to connect to the server. Please try again.');
      }
    } catch (error) {
      _showErrorDialog('An error occurred: $error');
    } finally {
      setState(() {
        _isLoading = false; // Hide loading indicator
      });
    }
  }

  // Show an error dialog
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Get the screen size to adjust layout for responsiveness
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SingleChildScrollView(  // Make the entire body scrollable
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Logo image
              Center(
                child: Image.asset(
                  'assets/images/logo.png', // Ensure this path matches your asset directory
                  width: screenWidth * 0.3,  // Adjust logo size relative to screen width
                  height: screenWidth * 0.3, // Adjust logo size relative to screen width
                ),
              ),
              SizedBox(height: screenHeight * 0.03), // Adjust spacing

              // Welcome back text
              Center(
                child: Text(
                  'Welcome back',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: screenHeight * 0.01), // Adjust spacing

              // Subtitle text
              Center(
                child: Text(
                  'Log In to get started.',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: Colors.grey,
                  ),
                ),
              ),
              SizedBox(height: screenHeight * 0.02), // Adjust spacing

              // "Let's Go" button under the text box
              Center(
                child: Container(
                  height: 40, // Adjust height as needed
                  width: 120, // Set width here to control size
                  decoration: BoxDecoration(
                    color: Color(0xFFEE7723), // Background color
                    borderRadius: BorderRadius.circular(32),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    'Let\'s Go',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              SizedBox(height: screenHeight * 0.02), // Adjust spacing

              // Mobile number input field
              TextField(
                controller: _mobileController,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.phone),
                  labelText: 'Mobile Number',
                  border: OutlineInputBorder(

                  ),
                  contentPadding: EdgeInsets.symmetric(vertical: 7), // Adjust vertical padding
                ),
                keyboardType: TextInputType.phone,
              ),
              SizedBox(height: screenHeight * 0.03), // Adjust spacing

              // Password input field
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.lock),
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(vertical: 7),
                ),
                obscureText: true,
              ),
              SizedBox(height: screenHeight * 0.02), // Adjust spacing

              // Forget password text
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Add action for forget password
                  },
                  child: Text('Forget password?',style: TextStyle(color:  Color(0xFFEE7723)),),
                ),
              ),
              SizedBox(height: screenHeight * 0.02), // Adjust spacing

              // Login button
              ElevatedButton(
                onPressed: _isLoading ? null : _login, // Disable if loading
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFEE7723), // Button color #EE7723
                  foregroundColor: Colors.white, // Text color
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: _isLoading
                    ? CircularProgressIndicator(color: Colors.white) // Show loader while logging in
                    : Text(
                  'Login',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
