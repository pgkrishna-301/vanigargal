import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomeScreen(),
  ));
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Get screen size for responsiveness
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.menu, color: Color(0xFFEE7723)),
          onPressed: () {
            // Open drawer action
          },
        ),
        title: Center(
          child: Image.asset(
            'assets/images/logo.png', // Ensure the logo path is correct
            width: screenWidth > 600 ? screenWidth * 0.25 : screenWidth * 0.15, // Adjust logo size based on screen size
            height: screenWidth > 600 ? screenWidth * 0.25 : screenWidth * 0.15, // Adjust logo size based on screen size
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Color(0xFFEE7723)),
            onPressed: () {
              // Handle notification action
            },
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Search Input Box
          Padding(
            padding: EdgeInsets.symmetric(
              vertical: screenHeight * 0.02, // Adjust vertical padding based on screen height
              horizontal: screenWidth * 0.06, // Adjust horizontal padding based on screen width
            ),
            child: Container(
              height: screenHeight * 0.06, // Adjust input box height based on screen height
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Color(0xFFEE7723)),
              ),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search...',
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.04, // Adjust content padding based on screen width
                    vertical: screenHeight * 0.02, // Adjust content padding based on screen height
                  ),
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.search, color: Color(0xFFEE7723)),
                ),
                onChanged: (text) {
                  // Handle search input change
                },
              ),
            ),
          ),

          // Categories row (New Arrival, Electronics, Sports, Books)
          Padding(
            padding: EdgeInsets.symmetric(
              vertical: screenHeight * 0.02, // Adjust vertical padding based on screen height
              horizontal: screenWidth * 0.06, // Adjust horizontal padding based on screen width
            ),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _categoryButton('New Arrival', screenWidth, screenHeight),
                  _categoryButton('Electronics', screenWidth, screenHeight),
                  _categoryButton('Sports', screenWidth, screenHeight),
                  _categoryButton('Books', screenWidth, screenHeight),
                ],
              ),
            ),
          ),

          // Scrollable product list
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _productCard(
                    productName: 'Product 1',
                    mrpPrice: '\$100',
                    ptrPrice: '\$80',
                    imageUrl: 'assets/images/product1.png', // Replace with actual image path
                    screenWidth: screenWidth,
                    screenHeight: screenHeight,
                  ),
                  _productCard(
                    productName: 'Product 2',
                    mrpPrice: '\$120',
                    ptrPrice: '\$90',
                    imageUrl: 'assets/images/product2.png', // Replace with actual image path
                    screenWidth: screenWidth,
                    screenHeight: screenHeight,
                  ),
                  _productCard(
                    productName: 'Product 3',
                    mrpPrice: '\$150',
                    ptrPrice: '\$110',
                    imageUrl: 'assets/images/product3.png', // Replace with actual image path
                    screenWidth: screenWidth,
                    screenHeight: screenHeight,
                  ),
                  // Add more products here...
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget for category buttons
  Widget _categoryButton(String title, double screenWidth, double screenHeight) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.02), // Adjust padding based on screen width
      child: ElevatedButton(
        onPressed: () {
          // Handle category selection
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0xFFEE7723),
          foregroundColor: Colors.white,
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.06, // Adjust padding based on screen width
            vertical: screenHeight * 0.02, // Adjust padding based on screen height
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: Text(title),
      ),
    );
  }

  // Widget for product cards
  Widget _productCard({
    required String productName,
    required String mrpPrice,
    required String ptrPrice,
    required String imageUrl,
    required double screenWidth,
    required double screenHeight,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: screenHeight * 0.02, // Adjust vertical padding based on screen height
        horizontal: screenWidth * 0.06, // Adjust horizontal padding based on screen width
      ),
      child: Container(
        height: screenHeight * 0.15, // Adjust container height based on screen height
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Product image and details
            Row(
              crossAxisAlignment: CrossAxisAlignment.start, // Align items to top
              children: [
                // Product image
                Container(
                  width: screenWidth * 0.3, // Adjust image width based on screen width
                  height: screenHeight * 0.15, // Adjust image height based on screen height
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    image: DecorationImage(
                      image: AssetImage(imageUrl),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(width: screenWidth * 0.04), // Adjust space between image and text

                // Product details (name, prices)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: screenHeight * 0.02), // Adjust padding based on screen height
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          productName,
                          style: TextStyle(
                            fontSize: screenWidth > 600 ? 18 : 16, // Adjust font size based on screen width
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(height: screenHeight * 0.01), // Adjust space based on screen height
                        Text(
                          'MRP: $mrpPrice',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey,
                            decoration: TextDecoration.lineThrough,
                          ),
                        ),
                        Text(
                          'PTR: $ptrPrice',
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFFEE7723),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // Positioned button at the bottom-right corner
            Positioned(
              bottom: 8, // Distance from the bottom of the container
              right: 8,  // Distance from the right side of the container
              child: SizedBox(
                width: screenWidth * 0.12, // Define your preferred width here
                child: ElevatedButton(
                  onPressed: () {
                    // Handle add to cart action
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFEE7723),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
