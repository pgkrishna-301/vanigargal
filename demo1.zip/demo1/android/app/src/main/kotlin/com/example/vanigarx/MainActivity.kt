package com.example.vanigarx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
